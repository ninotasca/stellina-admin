# Unoventi Frontend Platform

Owned source and release automation for the versioned `@ninotasca/web-platform` package.

## Planned surface

- `config`
- `logging`
- `errors`
- `http`
- `auth`
- `routing`
- `state`
- `ui`
- `ui/mantine` (optional application UI adapter)
- `testing`

There is intentionally no package-root export. Consumers import only the narrow
subpath they use, for example `@ninotasca/web-platform/http`. The NIN-379 scaffold
exports no runtime primitives yet; later ordered issues add only interfaces that
were proven in both reference applications.

## Project gate

The two-reference-app interface contract was frozen by [NIN-375](https://linear.app/unoventi/issue/NIN-375).
Repository ownership and release design are defined by [ADR 0001](docs/adr/0001-package-ownership-and-release-contract.md)
for [NIN-376](https://linear.app/unoventi/issue/NIN-376). Runtime extraction remains
gated on the ordered M4 issues in the architecture handoff.

## Boundaries

- No product feature, product route, secret, or sister-product source belongs here.
- Consumers use immutable released package versions, never local filesystem or source-copy dependencies.
- Browser code remains untrusted; backend authority stays in `unoventi-api`.

## Release-contract checks

```sh
npm run pack:dry-run
npm run test:release-contract
npm run validate
```

The rehearsal uses temporary directories and no registry credentials or network
publication. It proves immutable prerelease install, upgrade, and rollback shape;
it does not publish a package.

## UI entry

Applications using the UI primitives import the ordered default stylesheet once
from `@ninotasca/web-platform/ui/styles.css` before feature styles. Product themes
are validated data selected by application identity; platform components contain
no product branding, routes, or feature policy.

Application-style products can additionally install compatible Mantine peers
and import `createUnoventiMantineTheme` from
`@ninotasca/web-platform/ui/mantine`. Mantine is intentionally isolated behind
that optional subpath: lightweight public sites can continue to use semantic
tokens and CSS without installing or bundling a component framework.

Applications extend the default rather than editing package source:

```ts
import { createTheme } from '@mantine/core'
import { createUnoventiMantineTheme } from '@ninotasca/web-platform/ui/mantine'

export const applicationTheme = createUnoventiMantineTheme(createTheme({
  primaryColor: 'teal',
}))
```

Product layout, branding, feature components, and the decision to use Mantine
remain application-owned. The adapter supplies a preferred default, not a
mandatory rendering engine for every frontend.
