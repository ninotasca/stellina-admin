# ADR 0002: Optional Mantine application UI adapter

- Status: Accepted for UX prerelease
- Date: 2026-11-19

## Context

The stable platform already owns semantic design tokens, accessible lightweight
primitives, and application-bound theme overrides. Application products need a
broader maintained component set for forms, navigation, overlays, tables, and
responsive layout. Public sites must remain able to ship a minimal CSS-first
experience without inheriting an application framework.

## Decision

Mantine 9 is the preferred component foundation for Unoventi application-style
frontends. The platform exposes an additive `ui/mantine` subpath containing the
default Unoventi theme and a deterministic override factory. Mantine Core and
Hooks are optional peer dependencies. The existing `ui` and `ui/styles.css`
contracts remain independent of Mantine.

Applications install and import Mantine explicitly. They may extend or replace
the palette, typography, component defaults, and feature presentation through
Mantine theme overrides and application-owned components. Product branding and
business behavior never enter the shared adapter.

Charts are not part of the core adapter. Application dashboards may opt into
`@mantine/charts`; advanced large-scale visualization may use an explicitly
owned specialist package. Public sites do not receive either dependency by
default.

## Alternatives considered

- Tailwind-only application UI retained maximum CSS flexibility but continued
  to require bespoke accessible components and repeated product styling.
- Base UI provided a strong behavior layer but required Unoventi to author and
  maintain the full visual component system.
- Making Mantine a required root dependency would simplify app setup but would
  impose application weight on public and CSS-first consumers.

## Consequences

- Application products gain a polished and maintained default with less local
  CSS and component code.
- Lightweight sites retain a zero-Mantine path.
- Mantine major upgrades require a reviewed platform compatibility release.
- During migrations, products may temporarily ship both legacy styling and
  Mantine; that state must be measured and retired rather than becoming the
  permanent default.

## Migration and rollback

Consumers add exact compatible Mantine packages, import Mantine Core styles,
wrap the application with `MantineProvider`, and adopt the shared theme. A
consumer can roll back by restoring its previous platform and lockfile versions;
the existing lightweight UI contract remains available throughout.
