# ADR 0001: Package ownership and release contract

- Status: Accepted for M4 extraction; amended for GitHub ownership
- Date: 2026-11-18
- Linear: NIN-376

## Context

M3 proved the same narrow frontend interfaces in Unoventi Admin and Stellina
Admin. M4 needs one owned distribution without turning either application into a
source dependency, freezing product behavior into the platform, or making a
third-party library API part of Unoventi's public contract.

## Decision

### Ownership and source

The private `ninotasca/frontend-platform` repository is the only authoritative
source for `@ninotasca/web-platform`. Nino (`@ninotasca`) is the accountable owner
and initial maintainer. Application teams own their composition, features,
routes, branding, product policy, and upgrade decisions; they do not own or copy
the platform implementation.

The maintainer approves public API changes, compatibility declarations,
security releases, deprecations, and package promotion. A second reviewed
maintainer must be named before the first stable major is relied upon by more
than the two M4 reference applications.

### Registry and access

The approved distribution is GitHub Packages at `https://npm.pkg.github.com/`
under the `@ninotasca` scope, matching the owner of the private
`ninotasca/frontend-platform` repository. Repository access and package publish
access are restricted to maintainers. CI publication uses the protected
environment credential named `GITHUB_TOKEN`; documentation names the credential
but never records its value. Local release rehearsals may use the GitHub CLI's
keychain token without writing it to source or an `.npmrc` file.

Consumers install exact immutable versions from the registry. Git URLs,
branches, workspace links, `file:` dependencies, sister-repository imports, and
copied authoritative source are not release mechanisms. Released versions are
never overwritten or reused.

### Version and channel policy

Semantic Versioning applies to every public subpath, exported type, runtime
behavior, peer range, and documented contract:

- patch: compatible fixes and internal changes;
- minor: additive compatible exports or behavior;
- major: removals, renames, incompatible behavior, or narrowed compatibility.

Prereleases use `X.Y.Z-next.N` and the npm `next` dist-tag. Production releases
use `X.Y.Z` and the `latest` dist-tag. Promotion rebuilds from the reviewed commit
and verifies source commit, package manifest, tests, packed contents, attribution,
and digest; it does not retag an unverified local tarball.

The changelog records the source commit, compatibility matrix, migration notes,
security relevance, and rollback target for each release. Release automation
must fail closed when the working tree is dirty, the version/tag already exists,
tests or package-surface checks fail, or required release attribution is absent.

### Compatibility and support window

The package supports the current stable minor and the immediately preceding
minor for at least six months after supersession. Security fixes are provided
for the current major for at least twelve months after its first stable release,
unless a replacement major provides a documented safe migration sooner.

React, React DOM, React Router, and Supabase are explicit peer dependencies when
their subpaths are introduced. Initial target ranges are React/React DOM
`>=18.2 <20`, React Router DOM `>=6.22 <8`, and `@supabase/supabase-js >=2.45 <3`.
Peers used only by optional subpaths are marked optional. Consumer compatibility
tests exercise every supported major/minor combination before a range expands.
Provider clients, router objects, cache globals, and library-specific errors are
never exported as Unoventi contracts.

Established libraries may implement a platform mechanism only after comparison
against the frozen two-application contract. React Router is the current routing
peer. TanStack Query or an equivalent cache/query library and
`react-error-boundary` or an equivalent boundary library remain implementation
options for later extraction. Any selection stays behind Unoventi factories,
typed outcomes, and lifecycle interfaces and must not introduce a process-wide
singleton or observable library-specific behavior.

### Deprecation and security response

A normal deprecation is announced in the changelog and runtime/type documentation
in a minor release, retains a supported replacement for at least one minor and
90 days, and is removed only in a major release. The maintainer responds to a
reported compatibility regression within two business days and either publishes
a compatible patch, documents a safe rollback, or withdraws the affected
dist-tag. Security response timing is defined in `SECURITY.md`; urgent security
fixes may shorten the normal deprecation window with explicit advisory guidance.

### Setup and maintenance budget

For a minimum viable Vite application using the future starter and a warm package
cache, platform setup must require no more than 30 minutes of human work and no
manual platform-source copying. Routine platform maintenance must average no more
than two engineer-hours per consumer per month, excluding planned feature work,
major-version migrations, and active security incidents. Platform release
administration must average no more than four engineer-hours per month.

NIN-379 and later gates must measure these budgets. Exceeding one is a design
failure requiring simplification or an owner-approved ADR amendment; it is not a
reason to hide the cost in application code.

### Release and rollback

Each release is attributable to one Git commit and records its GitHub package,
repository, tag, and tarball digest. Stable automation must add a GitHub artifact
attestation when the package service supports the selected workflow. A consumer upgrade changes only the exact
package version and lockfile, then runs its full conformance/build/browser suite.
Rollback reinstalls the last known compatible exact version and lockfile and
reruns the same gates. Neither operation copies source or changes a dist-tag as a
substitute for changing the consumer's declared version.

The `test:release-contract` command performs an offline rehearsal: it packs two
immutable prerelease versions into isolated directories, installs version A,
upgrades to version B, and rolls back to A. This proves the distribution shape;
NIN-382 must additionally prove the real registry, attestation, upgrade, and
rollback path in both reference applications.

## Consequences

- Future product divergence is supported by pinning or forking at an explicit
  package version; applications are not forced to follow `latest`.
- Public subpaths remain narrow and independently reviewable.
- A registry outage cannot silently change installed code because versions and
  lockfiles are immutable, but a clean install still requires registry access or
  an approved cache.
- GitHub `ninotasca` ownership and `write:packages` permission must be confirmed
  before publication; consumer automation needs `read:packages` permission.

## Amendment: 2026-11-18 GitHub owner alignment

The owner confirmed that repositories and package distribution belong under the
existing `ninotasca` GitHub account; an earlier `Unoventi` parent is retired.
Accordingly, the package is `@ninotasca/web-platform`, sourced from
`ninotasca/frontend-platform`, and distributed through GitHub Packages. This
changes distribution identity only; the narrow public subpaths, SemVer policy,
compatibility window, product boundaries, upgrade model, and rollback model are
unchanged.
