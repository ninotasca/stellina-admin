# Changelog

All notable changes to `@ninotasca/web-platform` will be recorded here. The
format follows Keep a Changelog and releases follow Semantic Versioning.

## 0.3.1 - 2026-11-19

### Fixed

- Sortable table headers now render a semantic native column header so they
  work in both native tables and Mantine `Table` compositions without requiring
  a hidden component context.

### Compatibility

- The public pattern API and visual behavior are unchanged.
- Rollback target: `0.3.0`.

## 0.3.0 - 2026-11-19

### Added

- Product-neutral Mantine patterns for sortable table headers, all/none/subset
  multi-select filters, compact advanced-filter disclosure, filter clearing,
  and consistently spaced application modules.

### Changed

- Application tables now default to comfortable row and column spacing.
- Cards and papers now inherit a consistent bordered, lightly elevated surface.

### Compatibility

- The additions remain confined to the optional `ui/mantine` entry point, so
  lightweight consumers retain the dependency-free package path.
- Existing application overrides continue to win through
  `createUnoventiMantineTheme`.
- Rollback target: `0.2.0`.

## 0.2.0 - 2026-11-19

### Added

- Optional `ui/mantine` adapter with the default Unoventi application palette,
  typography, spacing, component defaults, reduced-motion behavior, and an
  application-owned override factory.
- Optional Mantine peer ranges so public/lightweight consumers of the existing
  UI and token contracts do not install or ship Mantine.

### Compatibility

- Existing `ui` and `ui/styles.css` exports are unchanged.
- Applications opt in by importing `@ninotasca/web-platform/ui/mantine` and
  installing compatible `@mantine/core` and `@mantine/hooks` peers.
- Public API and behavior are unchanged from the validated `0.2.0-next.0`
  release candidate.
- Rollback target: `0.1.0`.

## 0.1.0 - 2026-11-18

### Added

- First stable release of the nine reviewed platform subpath contracts.
- NIN-382 reproducible stable artifact plus two-consumer upgrade and rollback evidence.

### Compatibility

- Public API is unchanged from `0.1.0-next.0`.
- Unoventi Admin and Stellina Admin both validated upgrade from the prerelease,
  rollback to it, and re-upgrade to this stable version without copied source.

## 0.1.0-next.0 - 2026-11-18

### Added

- NIN-376 ownership, compatibility, release, and rollback contract.
- NIN-379 deterministic ESM/declaration build with nine narrow subpath exports.
- NIN-378 product-neutral configuration decoding, bounded browser logging, safe
  error normalization, and distinct public/protected HTTP client factories.
- NIN-377 site-bound authentication policy/session decoders, per-application
  in-memory credential store, provider-proof adapter, and generation-safe
  lifecycle controller.
- NIN-380 route-state helpers, abortable retained-data resources, accessible
  React primitives, semantic theme validation/default CSS, and deterministic
  auth/transport fixtures.
- NIN-381 GitHub Packages distribution under the `ninotasca` owner.
