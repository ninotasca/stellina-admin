# Security policy

Report suspected vulnerabilities privately to the accountable maintainer named
in [ADR 0001](docs/adr/0001-package-ownership-and-release-contract.md). Do not
open a public issue containing exploit details, credentials, tokens, cookies, or
private customer data.

The maintainer acknowledges a report within two business days, provides an
initial severity assessment within five business days, and coordinates a fix,
advisory, and supported-version guidance according to severity. Critical issues
may bypass the normal deprecation window. Consumers must be able to roll back to
the last compatible immutable release while a fix is prepared.

Publication uses the credential name `GITHUB_TOKEN`; its value belongs only in the
protected release environment and must never be committed to this repository.
